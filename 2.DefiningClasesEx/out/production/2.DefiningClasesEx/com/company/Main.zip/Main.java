package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class Main {

    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String line = reader.readLine();

        Map<Integer,BankAccount> accounts = new HashMap<>();
        while (!"end".equalsIgnoreCase(line)){



            doAction(accounts,line);

            line=reader.readLine();
        }

    }

    private static void doAction(Map<Integer, BankAccount> accounts, String line) {

        String [] data = line.split(" ");

        String command = data[0];
        int account;
        int money;
        switch (command){
            case "Deposit":
                account = Integer.parseInt(data[1]);
                money = Integer.parseInt(data[2]);
                try {
                    accounts.get(account).deposit(money);

                }catch (Exception e){
                    System.out.println("Account does not exist");
                }
                break;
            case "Create":
                account = Integer.parseInt(data[1]);

                if (!accounts.containsKey(account)){
                    accounts.put(account,new BankAccount(account,0.0));
                }else {
                    System.out.println("Account already exists");
                }
                break;
            case "Withdraw":
                account = Integer.parseInt(data[1]);
                money = Integer.parseInt(data[2]);
                 if (!accounts.containsKey(account)){
                     System.out.println("Account does not exist");
                     break;
                 }
                try {

                    accounts.get(account).withdraw(money);
                }catch (Exception e){
                    System.out.println("Insufficient balance");
                }


                break;
            case "Print":
                account = Integer.parseInt(data[1]);

                try {
                    System.out.println(accounts.get(account).toString());
                }catch (Exception e){
                    System.out.println("Account does not exist");
                }

                break;


        }
    }
}
